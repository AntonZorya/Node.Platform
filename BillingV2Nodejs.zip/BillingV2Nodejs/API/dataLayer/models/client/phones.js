exports.definition =
[{
	phoneNumber: { type: String, required: "#phoneNumber required" },
	phoneDescription: { type: String, required: "#phoneDescription required" },
	isMain: { type: Boolean, default: false }
}];