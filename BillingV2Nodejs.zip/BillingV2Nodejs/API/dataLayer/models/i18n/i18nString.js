exports.definition =  
	[{
		languageCode: {type:String, required: true},
		text: {type:String, required: true}
	}];