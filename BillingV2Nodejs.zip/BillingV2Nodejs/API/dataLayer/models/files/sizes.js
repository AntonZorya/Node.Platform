/**
 * Created by mac on 16.06.15.
 */
module.exports  = [
    {name: "original", width:null, height:null},
    {name: "thumb1", width: 100, height:100},
    {name: "thumb2", width:200, height:200},
    {name: "thumb3", width:300, height: 300}
]