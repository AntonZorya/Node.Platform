/**
 * Created by mac on 17.06.15.
 */
module.exports  = [
    {extension: "png", isImage: true},
    {extension: "jpg", isImage: true},
    {extension: "jpeg", isImage: true},
    {extension: "gif", isImage: true},
    {extension: "doc", isImage: false},
    {extension: "pdf", isImage: false},
    {extension: "xls", isImage: false},
    {extension: "docx", isImage: false},
    {extension: "xlsx", isImage: false}
]