
exports.definition =  { 
	shortName: {type:String, required: true},
	name: _i18nString,
	order: {type: Number, required: true}
};
