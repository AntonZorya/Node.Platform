﻿module.exports = {
    admin: { sysName: "admin", displayName: "#administrator"},
    organizationAdmin: {sysName: "organizationAdmin", displayName: "#organizationAdmin"},
    organizationUser: { sysName: "organizationUser", displayName: "#organizationUser" },
    controller: { sysName: "client", displayName: "#client" }
};