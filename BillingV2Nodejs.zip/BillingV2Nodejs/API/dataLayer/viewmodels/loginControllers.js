
exports.definition =  { 
	pinCode: {type: String, required: "#pinCode required"}
};


