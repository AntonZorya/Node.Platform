var configModule = angular.module('commonModule',[])
    .constant('WEB_HOST', 'http://localhost:9999')
    .constant('API_HOST', 'http://localhost:8080/API');