var configModule = angular.module('commonModule',[])
    .constant('WEB_HOST', 'http://localhost:9999')
    .constant('API_HOST', 'http://192.168.1.4:8080/API');