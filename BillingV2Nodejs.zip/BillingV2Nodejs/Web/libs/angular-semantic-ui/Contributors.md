  * [0xAX](https://twitter.com/0xAX) - author
 
Contributors:

  * [Nikita K.](https://github.com/Mendor)
  * [StudioThree10](https://github.com/studiothree10)
  * [cgroner](https://github.com/cgroner)
  * [solcates](https://github.com/solcates)
  * [jspdown](https://github.com/jspdown)
  * [xblaster](https://github.com/xblaster)
  * [frankt117](https://github.com/frankt117)
  * [tombee](https://github.com/tombee)
