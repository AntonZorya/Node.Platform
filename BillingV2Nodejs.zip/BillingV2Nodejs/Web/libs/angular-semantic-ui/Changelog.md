0.0.3 [Released]
=============================

  * Animated modal
  * Destroy listener was being called to destroy an accordion in the dropdown module
  * Corrected spelling in accordion README.md
  * Use semantic ui classes instead of inline style in the sidebar module


0.0.2 [Released]
=============================

  * Added wizard directive
  * Fixes to dropdown to update model, and allow for {{variables}} as title
  * Code clean up and grunt task optimization
  * Fixed scope issue with accordion
  * Updated modal to use ng-class
  * Updated accordion to use ng-class
  * Updated sidebar to use semantic-ui javascript functions
  * Updated README.md
  * Corrected spelling in rating module
  * Corrected opening problem for the dropdown


0.0.1 [Released]
=============================

  * Initial release;
  * Added `grunt build` task;
  * Added `grunt test`  task;
  * Added `karma` for testing;
  * `accordion` - initial release;
  * `checkbox`  - initial release;
  * `dimmer` - initial release;
  * `dropdown` - initial release;
  * `modal`    - initial release;
  * `popup`    - initial release;
  * `raiting`  - initial release;
  * `sidebar`  - initial release.